Drivers / Cuda
===========================================
https://developer.nvidia.com/cuda-downloads


Tutorial
===========================================
https://mirror.xyz/0x6758961d7c2F7C5AaEdDE282dBdCe160Ce91ea0B



Creat Coinbase address
===========================================
http://www.doji.today/



Pool
===========================================
Global1:
stratum+tcp://miner.bitforcepool.com:3333
Global2:
stratum+tcp://pool.bitforcepool.com:3333
US:
stratum+tcp://us.bitforcepool.com:3333
Japan:
stratum+tcp://jp.bitforcepool.com:3333
Europe:
stratum+tcp://eur.bitforcepool.com:3333
Asia:
stratum+tcp://asia.bitforcepool.com:3333
Africa:
stratum+tcp://af.bitforcepool.com:3333
Canada:
stratum+tcp://ca.bitforcepool.com:3333
Finland:
stratum+tcp://fin.bitforcepool.com:3333
Singapore:
stratum+tcp://sin.bitforcepool.com:3333
Australia:
stratum+tcp://au.bitforcepool.com:3333
